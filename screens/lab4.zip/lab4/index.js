import React from 'react';
import { View } from 'react-native';
import ListCourre from '../../component/list';

const Lab4 = () => {
    return (
        <View>
            <ListCourre/>

        </View>
    );
};

export default React.memo(Lab4);